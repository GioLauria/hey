mupdf_location = 'https://mupdf.com/downloads/archive/mupdf-1.27.1-source.tar.gz'
pymupdf_version = '1.27.1'
pymupdf_version_tuple = (1, 27, 1)
pymupdf_git_sha = ''
pymupdf_git_diff = ''
pymupdf_git_branch = 'main'
swig_version = '4.4.1'
swig_version_tuple = (4, 4, 1)
