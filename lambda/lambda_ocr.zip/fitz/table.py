# pylint: disable=wildcard-import,unused-wildcard-import
from pymupdf.table import *
